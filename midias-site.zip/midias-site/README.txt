Laboratório de Mídias (Web) — Mini-site

Abra o arquivo midias-site/index.html no navegador.
Cada página demonstra uma mídia: vídeo, imagem, gif, áudio, cursor, emotions.

Pasta assets/ (opcional):
- bg.mp4
- cursor.png
- foto.png / foto2.png
- anim.gif
- click.mp3 / error.mp3 / music.mp3
- happy.gif / angry.gif / sad.gif / calm.gif

Se você não tiver os arquivos, os exemplos usam URLs de fallback e continuam funcionando.
